Tutorial exercises
------------------

Exercises for the tutorials
